package ru.V5Minecraft.MultiColoredBlocks.Register;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import ru.V5Minecraft.MultiColoredBlocks.blocks.*;

public class RegisterBlocks {
    public static Block RedPlanks = new Wood("redplanks");
    public static Block LightBluePlanks = new Wood("lightblueplanks");
    public static Block BluePlanks = new Wood("blueplanks");
    public static Block RedOakLog = new Wood("redoaklog");
    public static Block LightRedOakLog = new Wood("lightblueoaklog");
    public static Block BlueOakLog = new Wood("blueoaklog");
    public static Block GreenOakLog = new Wood("greenoaklog");
    public static Block PurpleOakLog = new Wood("purpleoaklog");
    public static Block YellowOakLog = new Wood("yellowoaklog");
    public static Block GreenPlanks = new Wood("greenplanks");
    public static Block OrangePlanks = new Wood("orangeplanks");
    public static Block OrangeOakLog = new Wood("orangeoaklog");
    public static Block YellowPlanks = new Wood("yellowplanks");
    public static Block PurplePlanks = new Wood("purpleplanks");
    public static Block RedFence = new Fence("redfence");
    public static Block LightBlueFence = new Fence("lightbluefence");
    public static Block BlueFence = new Fence("bluefence");
    public static Block GreenFence = new Fence("greenfence");
    public static Block OrangeFence = new Fence("orangefence");
    public static Block YellowFence = new Fence("yellowfence");
    public static Block PurpleFence = new Fence("purplefence");
    public static Block RedStair = new Stair("redstair", RedPlanks.getDefaultState());
    public static Block LightBlueStair = new Stair("lightbluestair", LightBluePlanks.getDefaultState());
    public static Block BlueStair = new Stair("bluestair", BluePlanks.getDefaultState());
    public static Block GreenStair = new Stair("greenstair", GreenPlanks.getDefaultState());
    public static Block OrangeStair = new Stair("orangestair", OrangePlanks.getDefaultState());
    public static Block YellowStair = new Stair("yellowstair", YellowPlanks.getDefaultState());
    public static Block PurpleStair = new Stair("purplestair", PurplePlanks.getDefaultState());
    public static Block RedLadder = new Ladder("redladder");
    public static Block LightBlueLadder = new Ladder("lightblueladder");
    public static Block BlueLadder = new Ladder("blueladder");
    public static Block GreenLadder = new Ladder("greenladder");
    public static Block OrangeLadder = new Ladder("orangeladder");
    public static Block YellowLadder = new Ladder("yellowladder");
    public static Block PurpleLadder = new Ladder("purpleladder");

    public static void register() {
        setRegister(RedPlanks);
        setRegister(LightBluePlanks);
        setRegister(RedOakLog);
        setRegister(LightRedOakLog);
        setRegister(BluePlanks);
        setRegister(BlueOakLog);
        setRegister(GreenOakLog);
        setRegister(PurpleOakLog);
        setRegister(YellowOakLog);
        setRegister(GreenPlanks);
        setRegister(OrangePlanks);
        setRegister(OrangeOakLog);
        setRegister(YellowPlanks);
        setRegister(PurplePlanks);
        setRegister(RedFence);
        setRegister(LightBlueFence);
        setRegister(BlueFence);
        setRegister(GreenFence);
        setRegister(OrangeFence);
        setRegister(YellowFence);
        setRegister(PurpleFence);
        setRegister(RedStair);
        setRegister(LightBlueStair);
        setRegister(BlueStair);
        setRegister(GreenStair);
        setRegister(OrangeStair);
        setRegister(YellowStair);
        setRegister(PurpleStair);
        setRegister(RedLadder);
        setRegister(LightBlueLadder);
        setRegister(BlueLadder);
        setRegister(GreenLadder);
        setRegister(OrangeLadder);
        setRegister(YellowLadder);
        setRegister(PurpleLadder);
    }

    @SideOnly(Side.CLIENT)
    public static void registerRender() {
        setRender(RedPlanks);
        setRender(LightBluePlanks);
        setRender(RedOakLog);
        setRender(LightRedOakLog);
        setRender(BluePlanks);
        setRender(BlueOakLog);
        setRender(GreenOakLog);
        setRender(PurpleOakLog);
        setRender(YellowOakLog);
        setRender(GreenPlanks);
        setRender(OrangePlanks);
        setRender(OrangeOakLog);
        setRender(YellowPlanks);
        setRender(PurplePlanks);
        setRender(RedFence);
        setRender(LightBlueFence);
        setRender(BlueFence);
        setRender(GreenFence);
        setRender(OrangeFence);
        setRender(YellowFence);
        setRender(PurpleFence);
        setRender(RedStair);
        setRender(LightBlueStair);
        setRender(BlueStair);
        setRender(GreenStair);
        setRender(OrangeStair);
        setRender(YellowStair);
        setRender(PurpleStair);
        setRender(RedLadder);
        setRender(LightBlueLadder);
        setRender(BlueLadder);
        setRender(GreenLadder);
        setRender(OrangeLadder);
        setRender(YellowLadder);
        setRender(PurpleLadder);
    }

    private static void setRegister(Block block) {
        ForgeRegistries.BLOCKS.register(block);
        ForgeRegistries.ITEMS.register(new ItemBlock(block).setRegistryName(block.getRegistryName()));
    }

    @SideOnly(Side.CLIENT)
    private static void setRender(Block block) {
        Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(Item.getItemFromBlock(block), 0, new ModelResourceLocation(block.getRegistryName(), "inventory"));
    }
}
