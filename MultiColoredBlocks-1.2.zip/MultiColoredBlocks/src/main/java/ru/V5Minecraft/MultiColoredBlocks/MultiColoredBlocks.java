package ru.V5Minecraft.MultiColoredBlocks;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import ru.V5Minecraft.MultiColoredBlocks.Proxy.CommonProxy;
import ru.V5Minecraft.MultiColoredBlocks.Register.RegisterBlocks;

@Mod(modid = "multicoloredblocks", name = "MultiColored Blocks", version = "1.2")
public class MultiColoredBlocks {
    public static final CreativeTabs tabMultiColoredBlocks = new CreativeTabs("tabMultiColoredBlocks") {
        public ItemStack getTabIconItem() {
            return new ItemStack(RegisterBlocks.RedPlanks);
        }
    };

    @SidedProxy(clientSide = "ru.V5Minecraft.MultiColoredBlocks.Proxy.ClientProxy", serverSide = "ru.V5Minecraft.MultiColoredBlocks.Proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        proxy.preInit(event);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        proxy.postInit(event);
    }
}
