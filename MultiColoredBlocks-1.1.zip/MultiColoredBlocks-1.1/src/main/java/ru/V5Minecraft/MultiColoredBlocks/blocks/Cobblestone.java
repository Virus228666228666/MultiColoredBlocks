package ru.V5Minecraft.MultiColoredBlocks.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockStone;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyEnum;
import ru.V5Minecraft.MultiColoredBlocks.MultiColoredBlocks;

public class Cobblestone extends Block {
    public Cobblestone(String name) {
        super(Material.ROCK);
        this.setHardness(5.0F);
        this.setUnlocalizedName(name);
        this.setRegistryName(name);
        this.setCreativeTab(MultiColoredBlocks.tabMultiColoredBlocks);
    }
}
