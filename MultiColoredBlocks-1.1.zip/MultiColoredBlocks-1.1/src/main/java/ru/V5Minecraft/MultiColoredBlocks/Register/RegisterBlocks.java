package ru.V5Minecraft.MultiColoredBlocks.Register;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import ru.V5Minecraft.MultiColoredBlocks.blocks.*;

public class RegisterBlocks {
    public static Block RedPlanks = new Wood("redplanks");
    public static Block LightBluePlanks = new Wood("lightblueplanks");
    public static Block BluePlanks = new Wood("blueplanks");
    public static Block RedCobblestone = new Cobblestone("redcobblestone");
    public static Block LightBlueCobblestone = new Cobblestone("lightbluecobblestone");
    public static Block RedOakLog = new Wood("redoaklog");
    public static Block LightRedOakLog = new Wood("lightblueoaklog");
    public static Block BlueOakLog = new Wood("blueoaklog");
    public static Block GreenOakLog = new Wood("greenoaklog");
    public static Block VioletOakLog = new Wood("violetoaklog");
    public static Block YellowOakLog = new Wood("yellowoaklog");
    public static Block GreenPlanks = new Wood("greenplanks");

    public static void register() {
        setRegister(RedPlanks);
        setRegister(LightBluePlanks);
        setRegister(RedCobblestone);
        setRegister(LightBlueCobblestone);
        setRegister(RedOakLog);
        setRegister(LightRedOakLog);
        setRegister(BluePlanks);
        setRegister(BlueOakLog);
        setRegister(GreenOakLog);
        setRegister(VioletOakLog);
        setRegister(YellowOakLog);
        setRegister(GreenPlanks);
    }

    @SideOnly(Side.CLIENT)
    public static void registerRender() {
        setRender(RedPlanks);
        setRender(LightBluePlanks);
        setRender(RedCobblestone);
        setRender(LightBlueCobblestone);
        setRender(RedOakLog);
        setRender(LightRedOakLog);
        setRender(BluePlanks);
        setRender(BlueOakLog);
        setRender(GreenOakLog);
        setRender(VioletOakLog);
        setRender(YellowOakLog);
        setRender(GreenPlanks);
    }

    private static void setRegister(Block block) {
        ForgeRegistries.BLOCKS.register(block);
        ForgeRegistries.ITEMS.register(new ItemBlock(block).setRegistryName(block.getRegistryName()));
    }

    @SideOnly(Side.CLIENT)
    private static void setRender(Block block) {
        Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(Item.getItemFromBlock(block), 0, new ModelResourceLocation(block.getRegistryName(), "inventory"));
    }
}
