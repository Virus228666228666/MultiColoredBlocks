package ru.V5Minecraft.MultiColoredBlocks.CreativeTab;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import ru.V5Minecraft.MultiColoredBlocks.Register.RegisterBlocks;

public class TabMultiColoredBlocks extends CreativeTabs {
    public TabMultiColoredBlocks(String label) {
        super(label);
    }

    @Override
    public ItemStack getTabIconItem() {
        return new ItemStack(RegisterBlocks.RedPlanks);
    }

    @Override
    public void displayAllRelevantItems(NonNullList<ItemStack> items) {
        items.clear();

        items.add(new ItemStack(RegisterBlocks.RedPlanks));
        items.add(new ItemStack(RegisterBlocks.LightBluePlanks));
        items.add(new ItemStack(RegisterBlocks.BluePlanks));
        items.add(new ItemStack(RegisterBlocks.GreenPlanks));
        items.add(new ItemStack(RegisterBlocks.OrangePlanks));
        items.add(new ItemStack(RegisterBlocks.YellowPlanks));
        items.add(new ItemStack(RegisterBlocks.PurplePlanks));

        items.add(new ItemStack(RegisterBlocks.RedOakLog));
        items.add(new ItemStack(RegisterBlocks.LightBlueOakLog));
        items.add(new ItemStack(RegisterBlocks.BlueOakLog));
        items.add(new ItemStack(RegisterBlocks.GreenOakLog));
        items.add(new ItemStack(RegisterBlocks.OrangeOakLog));
        items.add(new ItemStack(RegisterBlocks.YellowOakLog));
        items.add(new ItemStack(RegisterBlocks.PurpleOakLog));

        items.add(new ItemStack(RegisterBlocks.RedDoor));
        items.add(new ItemStack(RegisterBlocks.LightBlueDoor));
        items.add(new ItemStack(RegisterBlocks.BlueDoor));
        items.add(new ItemStack(RegisterBlocks.GreenDoor));
        items.add(new ItemStack(RegisterBlocks.OrangeDoor));
        items.add(new ItemStack(RegisterBlocks.YellowDoor));
        items.add(new ItemStack(RegisterBlocks.PurpleDoor));

        items.add(new ItemStack(RegisterBlocks.RedTrapDoor));
        items.add(new ItemStack(RegisterBlocks.LightBlueTrapDoor));
        items.add(new ItemStack(RegisterBlocks.BlueTrapDoor));
        items.add(new ItemStack(RegisterBlocks.GreenTrapDoor));
        items.add(new ItemStack(RegisterBlocks.OrangeTrapDoor));
        items.add(new ItemStack(RegisterBlocks.YellowTrapDoor));
        items.add(new ItemStack(RegisterBlocks.PurpleTrapDoor));

        items.add(new ItemStack(RegisterBlocks.RedLadder));
        items.add(new ItemStack(RegisterBlocks.LightBlueLadder));
        items.add(new ItemStack(RegisterBlocks.BlueLadder));
        items.add(new ItemStack(RegisterBlocks.GreenLadder));
        items.add(new ItemStack(RegisterBlocks.OrangeLadder));
        items.add(new ItemStack(RegisterBlocks.YellowLadder));
        items.add(new ItemStack(RegisterBlocks.PurpleLadder));

        items.add(new ItemStack(RegisterBlocks.RedStair));
        items.add(new ItemStack(RegisterBlocks.LightBlueStair));
        items.add(new ItemStack(RegisterBlocks.BlueStair));
        items.add(new ItemStack(RegisterBlocks.GreenStair));
        items.add(new ItemStack(RegisterBlocks.OrangeStair));
        items.add(new ItemStack(RegisterBlocks.YellowStair));
        items.add(new ItemStack(RegisterBlocks.PurpleStair));

        items.add(new ItemStack(RegisterBlocks.RedIronBars));
        items.add(new ItemStack(RegisterBlocks.LightBlueIronBars));
        items.add(new ItemStack(RegisterBlocks.BlueIronBars));
        items.add(new ItemStack(RegisterBlocks.GreenIronBars));
        items.add(new ItemStack(RegisterBlocks.OrangeIronBars));
        items.add(new ItemStack(RegisterBlocks.YellowIronBars));
        items.add(new ItemStack(RegisterBlocks.PurpleIronBars));

        items.add(new ItemStack(RegisterBlocks.RedFence));
        items.add(new ItemStack(RegisterBlocks.LightBlueFence));
        items.add(new ItemStack(RegisterBlocks.BlueFence));
        items.add(new ItemStack(RegisterBlocks.GreenFence));
        items.add(new ItemStack(RegisterBlocks.OrangeFence));
        items.add(new ItemStack(RegisterBlocks.YellowFence));
        items.add(new ItemStack(RegisterBlocks.PurpleFence));

        items.add(new ItemStack(RegisterBlocks.RedPressurePlate));
        items.add(new ItemStack(RegisterBlocks.LightBluePressurePlate));
        items.add(new ItemStack(RegisterBlocks.BluePressurePlate));
        items.add(new ItemStack(RegisterBlocks.GreenPressurePlate));
        items.add(new ItemStack(RegisterBlocks.OrangePressurePlate));
        items.add(new ItemStack(RegisterBlocks.YellowPressurePlate));
        items.add(new ItemStack(RegisterBlocks.PurplePressurePlate));

        items.add(new ItemStack(RegisterBlocks.RedStoneSlab));
        items.add(new ItemStack(RegisterBlocks.LightBlueStoneSlab));
        items.add(new ItemStack(RegisterBlocks.BlueStoneSlab));
        items.add(new ItemStack(RegisterBlocks.GreenStoneSlab));
        items.add(new ItemStack(RegisterBlocks.OrangeStoneSlab));
        items.add(new ItemStack(RegisterBlocks.YellowStoneSlab));
        items.add(new ItemStack(RegisterBlocks.PurpleStoneSlab));

        super.displayAllRelevantItems(items);
    }
}
