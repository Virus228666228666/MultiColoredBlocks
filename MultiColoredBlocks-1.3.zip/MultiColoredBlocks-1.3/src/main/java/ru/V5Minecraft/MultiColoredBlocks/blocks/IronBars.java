package ru.V5Minecraft.MultiColoredBlocks.blocks;

import net.minecraft.block.BlockPane;
import net.minecraft.block.material.Material;

public class IronBars extends BlockPane {
    public IronBars(String name) {
        super(Material.IRON, true);
        this.setHardness(5.0F);
        this.setResistance(10.0F);
        this.setUnlocalizedName(name);
        this.setRegistryName(name);
        this.setCreativeTab(null);
    }
}
