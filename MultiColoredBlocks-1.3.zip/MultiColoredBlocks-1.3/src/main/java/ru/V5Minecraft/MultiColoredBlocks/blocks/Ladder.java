package ru.V5Minecraft.MultiColoredBlocks.blocks;

import net.minecraft.block.BlockLadder;

public class Ladder extends BlockLadder {
    public Ladder(String name) {
        this.setHardness(2.0F);
        this.setUnlocalizedName(name);
        this.setRegistryName(name);
        this.setCreativeTab(null);
    }
}
