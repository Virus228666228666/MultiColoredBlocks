package ru.V5Minecraft.MultiColoredBlocks.blocks;

import net.minecraft.block.BlockFence;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public class Fence extends BlockFence {
    public Fence(String name) {
        super(Material.WOOD, MapColor.WOOD);
        this.setHardness(2.0F);
        this.setUnlocalizedName(name);
        this.setRegistryName(name);
        this.setCreativeTab(null);
    }
}
