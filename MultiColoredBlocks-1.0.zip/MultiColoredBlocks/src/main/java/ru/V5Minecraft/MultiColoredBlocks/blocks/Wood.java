package ru.V5Minecraft.MultiColoredBlocks.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import ru.V5Minecraft.MultiColoredBlocks.MultiColoredBlocks;

public class Wood extends Block {
    public Wood(String name) {
        super(Material.WOOD);
        this.setHarvestLevel("hand", 2);
        this.setUnlocalizedName(name);
        this.setRegistryName(name);
        this.setCreativeTab(MultiColoredBlocks.tabMultiColoredBlocks);
    }
}
